# Quantum-Inspired Adaptive Airport Gate Assignment System

## Project Overview

This project develops a quantum-inspired constraint optimization framework
for airport gate assignment with dynamic flight delay handling.

The system uses live flight information, assigns flights to compatible gates,
detects gate conflicts, and performs adaptive re-optimization when delays
affect the original assignment.

## Workflow

Live Flight Data
        ↓
Data Preprocessing
        ↓
Gate Constraints
        ↓
Initial Gate Assignment
        ↓
Quantum-Inspired Optimization
        ↓
Delay Detection
        ↓
Conflict Detection
        ↓
Adaptive Re-optimization
        ↓
Performance Evaluation
        ↓
Streamlit Dashboard

## Main Components

- Live flight data collection
- Flight data preprocessing
- Gate compatibility constraints
- Initial gate assignment
- Quantum-inspired optimization
- Dynamic delay simulation
- Conflict detection
- Adaptive re-optimization
- Performance evaluation
- Interactive Streamlit dashboard

## Technologies

- Python
- Pandas
- NumPy
- SciPy
- Streamlit
- Plotly
- Matplotlib
- Aviationstack API

## Important Note

The quantum-inspired method is a classical optimization heuristic inspired
by quantum concepts. It does not require a quantum computer.

The gate configuration used in this prototype is a research configuration
and does not represent the actual live gate availability of an airport.

## Deployment

The application can be deployed using:

GitHub → Render → Streamlit

The Aviationstack API key should be stored securely as an environment
variable and should not be committed to GitHub.
