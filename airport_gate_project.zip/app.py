
import streamlit as st
import pandas as pd
import numpy as np
import requests
from datetime import timedelta

# ============================================================
# PAGE CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="Quantum-Inspired Airport Gate Assignment",
    page_icon="✈️",
    layout="wide"
)

st.title("✈️ Quantum-Inspired Adaptive Airport Gate Assignment System")
st.write(
    "Live flight data → Gate assignment → Delay handling → "
    "Conflict detection → Adaptive re-optimization"
)

# ============================================================
# GATE CONFIGURATION
# ============================================================

gate_data = {
    "gate_id": [
        "G01", "G02", "G03", "G04", "G05",
        "G06", "G07", "G08", "G09", "G10"
    ],
    "terminal": [
        "T1", "T1", "T1", "T1", "T1",
        "T2", "T2", "T2", "T2", "T2"
    ],
    "gate_type": [
        "Domestic", "Domestic", "Domestic", "Domestic", "Domestic",
        "International", "International", "International",
        "International", "International"
    ],
    "aircraft_type": [
        "Narrow", "Narrow", "Narrow", "Wide", "Narrow",
        "Wide", "Narrow", "Wide", "Narrow", "Wide"
    ],
    "available": [True] * 10
}

gates_df = pd.DataFrame(gate_data)

st.subheader("1. Gate Configuration")
st.dataframe(gates_df, use_container_width=True)

# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.header("System Controls")

delay_percentage = st.sidebar.slider(
    "Delay Percentage",
    min_value=0,
    max_value=30,
    value=20,
    step=5
)

flight_limit = st.sidebar.slider(
    "Number of Flights",
    min_value=1,
    max_value=10,
    value=10
)

# ============================================================
# FETCH LIVE FLIGHTS
# ============================================================

def fetch_live_flights(api_key, limit=10):

    url = "https://api.aviationstack.com/v1/flights"

    params = {
        "access_key": api_key,
        "limit": limit
    }

    try:

        response = requests.get(
            url,
            params=params,
            timeout=20
        )

        if response.status_code != 200:
            return None, f"HTTP Error: {response.status_code}"

        result = response.json()

        if "error" in result:
            return None, str(result["error"])

        flights = result.get("data", [])

        if len(flights) == 0:
            return None, "No flight data returned."

        rows = []

        for flight in flights:

            departure = flight.get("departure", {})
            arrival = flight.get("arrival", {})
            airline = flight.get("airline", {})
            flight_info = flight.get("flight", {})

            rows.append({
                "flight_number": flight_info.get("iata"),
                "airline": airline.get("name"),

                "departure_airport": departure.get("airport"),
                "departure_iata": departure.get("iata"),
                "departure_scheduled": departure.get("scheduled"),
                "departure_estimated": departure.get("estimated"),

                "arrival_airport": arrival.get("airport"),
                "arrival_iata": arrival.get("iata"),
                "arrival_scheduled": arrival.get("scheduled"),
                "arrival_estimated": arrival.get("estimated"),

                "status": flight.get("flight_status")
            })

        return pd.DataFrame(rows), None

    except Exception as e:

        return None, str(e)


# ============================================================
# PREPROCESSING
# ============================================================

def preprocess_flights(df):

    df = df.copy()

    time_columns = [
        "arrival_scheduled",
        "arrival_estimated",
        "departure_scheduled",
        "departure_estimated"
    ]

    for column in time_columns:

        if column in df.columns:

            df[column] = pd.to_datetime(
                df[column],
                errors="coerce",
                utc=True
            )

    df["arrival_time"] = (
        df["arrival_estimated"]
        .fillna(df["arrival_scheduled"])
    )

    df["departure_time"] = (
        df["departure_estimated"]
        .fillna(df["departure_scheduled"])
    )

    # Prototype aircraft classification
    np.random.seed(42)

    df["aircraft_type"] = np.random.choice(
        ["Narrow", "Wide"],
        size=len(df)
    )

    df = df.dropna(
        subset=["arrival_time", "departure_time"]
    )

    df = df.reset_index(drop=True)

    return df


# ============================================================
# COMPATIBLE GATES
# ============================================================

def get_compatible_gates(flight, gates):

    compatible = gates[
        (gates["available"] == True) &
        (gates["aircraft_type"] == flight["aircraft_type"])
    ]

    return compatible["gate_id"].tolist()


# ============================================================
# INITIAL GREEDY ASSIGNMENT
# ============================================================

def greedy_assignment(flights, gates):

    flights = flights.copy()

    flights = flights.sort_values(
        "arrival_time"
    ).reset_index(drop=True)

    gate_release = {
        gate: pd.Timestamp.min
        for gate in gates["gate_id"]
    }

    solution = {}

    turnaround = timedelta(minutes=30)

    for _, flight in flights.iterrows():

        compatible_gates = get_compatible_gates(
            flight,
            gates
        )

        selected_gate = None

        for gate in compatible_gates:

            if flight["arrival_time"] >= gate_release[gate]:

                selected_gate = gate
                break

        solution[flight["flight_number"]] = selected_gate

        if selected_gate is not None:

            gate_release[selected_gate] = (
                flight["departure_time"]
                + turnaround
            )

    return solution


# ============================================================
# QUANTUM-INSPIRED ASSIGNMENT
# ============================================================

def quantum_inspired_assignment(flights, gates, iterations=100):

    best_solution = None
    best_cost = float("inf")

    for iteration in range(iterations):

        solution = {}

        for _, flight in flights.iterrows():

            compatible_gates = get_compatible_gates(
                flight,
                gates
            )

            if compatible_gates:

                selected_gate = np.random.choice(
                    compatible_gates
                )

                solution[
                    flight["flight_number"]
                ] = selected_gate

            else:

                solution[
                    flight["flight_number"]
                ] = None

        unassigned = sum(
            1
            for gate in solution.values()
            if gate is None
        )

        gates_used = len(
            set(
                gate
                for gate in solution.values()
                if gate is not None
            )
        )

        cost = (
            500 * unassigned
            + 5 * gates_used
        )

        if cost < best_cost:

            best_cost = cost
            best_solution = solution.copy()

    return best_solution, best_cost


# ============================================================
# DELAY SCENARIO
# ============================================================

def create_delay_scenario(flights, percentage):

    delayed_df = flights.copy()

    delayed_df["delay_minutes"] = 0

    number_of_delayed = int(
        len(delayed_df) * percentage / 100
    )

    if number_of_delayed > 0:

        np.random.seed(42)

        delayed_indices = np.random.choice(
            delayed_df.index,
            size=number_of_delayed,
            replace=False
        )

        delayed_values = np.random.randint(
            15,
            121,
            size=number_of_delayed
        )

        delayed_df.loc[
            delayed_indices,
            "delay_minutes"
        ] = delayed_values

    delayed_df["delayed_arrival"] = (
        delayed_df["arrival_time"]
        + pd.to_timedelta(
            delayed_df["delay_minutes"],
            unit="m"
        )
    )

    delayed_df["delayed_departure"] = (
        delayed_df["departure_time"]
        + pd.to_timedelta(
            delayed_df["delay_minutes"],
            unit="m"
        )
    )

    delayed_df["delayed_gate_release"] = (
        delayed_df["delayed_departure"]
        + pd.Timedelta(minutes=30)
    )

    return delayed_df


# ============================================================
# CONFLICT DETECTION
# ============================================================

def detect_conflicts(
    flights,
    solution,
    arrival_column,
    release_column
):

    df = flights.copy()

    df["assigned_gate"] = (
        df["flight_number"].map(solution)
    )

    assigned = df[
        df["assigned_gate"].notna()
    ].copy()

    conflicts = []

    for gate in assigned["assigned_gate"].unique():

        gate_flights = assigned[
            assigned["assigned_gate"] == gate
        ].sort_values(
            arrival_column
        )

        for i in range(
            len(gate_flights) - 1
        ):

            current = gate_flights.iloc[i]

            next_flight = gate_flights.iloc[i + 1]

            if (
                next_flight[arrival_column]
                <
                current[release_column]
            ):

                conflicts.append({
                    "gate": gate,
                    "flight_1": current["flight_number"],
                    "flight_2": next_flight["flight_number"]
                })

    return pd.DataFrame(conflicts)


# ============================================================
# ADAPTIVE RE-OPTIMIZATION
# ============================================================

def adaptive_reoptimization(
    delayed_flights,
    initial_solution,
    gates
):

    solution = initial_solution.copy()

    conflicts = detect_conflicts(
        delayed_flights,
        solution,
        "delayed_arrival",
        "delayed_gate_release"
    )

    affected_flights = set()

    for _, row in conflicts.iterrows():

        affected_flights.add(
            row["flight_1"]
        )

        affected_flights.add(
            row["flight_2"]
        )

    delayed_flight_ids = set(
        delayed_flights.loc[
            delayed_flights["delay_minutes"] > 0,
            "flight_number"
        ]
    )

    affected_flights.update(
        delayed_flight_ids
    )

    # Remove affected assignments
    for flight_id in affected_flights:

        solution[flight_id] = None

    # Reserve gates used by unaffected flights
    reserved_gates = set()

    for flight_id, gate in solution.items():

        if (
            flight_id not in affected_flights
            and gate is not None
        ):

            reserved_gates.add(gate)

    affected_df = delayed_flights[
        delayed_flights["flight_number"].isin(
            affected_flights
        )
    ].sort_values(
        "delayed_arrival"
    )

    gate_release = {}

    for gate in gates["gate_id"]:

        if gate in reserved_gates:

            gate_release[gate] = pd.Timestamp.max

        else:

            gate_release[gate] = pd.Timestamp.min

    turnaround = timedelta(minutes=30)

    # Reassign affected flights
    for _, flight in affected_df.iterrows():

        compatible = get_compatible_gates(
            flight,
            gates
        )

        selected_gate = None

        for gate in compatible:

            if (
                flight["delayed_arrival"]
                >= gate_release[gate]
            ):

                selected_gate = gate
                break

        solution[
            flight["flight_number"]
        ] = selected_gate

        if selected_gate is not None:

            gate_release[selected_gate] = (
                flight["delayed_gate_release"]
            )

    return solution, affected_flights


# ============================================================
# STREAMLIT BUTTON
# ============================================================

st.sidebar.subheader("Live Data")

api_key = st.sidebar.text_input(
    "Aviationstack API Key",
    type="password"
)

fetch_button = st.sidebar.button(
    "Fetch Live Flights"
)

# ============================================================
# MAIN WORKFLOW
# ============================================================

if fetch_button:

    if not api_key:

        st.error(
            "Please enter your Aviationstack API key."
        )

    else:

        # ----------------------------------------------------
        # LIVE DATA
        # ----------------------------------------------------

        raw_flights, error = fetch_live_flights(
            api_key,
            flight_limit
        )

        if error:

            st.error(
                f"API Error: {error}"
            )

        else:

            st.success(
                f"Successfully retrieved {len(raw_flights)} flights."
            )

            st.subheader(
                "2. Live Flight Data"
            )

            st.dataframe(
                raw_flights,
                use_container_width=True
            )

            # ------------------------------------------------
            # PREPROCESSING
            # ------------------------------------------------

            flights = preprocess_flights(
                raw_flights
            )

            st.subheader(
                "3. Preprocessed Flight Data"
            )

            st.dataframe(
                flights[
                    [
                        "flight_number",
                        "airline",
                        "arrival_time",
                        "departure_time",
                        "aircraft_type",
                        "status"
                    ]
                ],
                use_container_width=True
            )

            # ------------------------------------------------
            # INITIAL ASSIGNMENT
            # ------------------------------------------------

            st.subheader(
                "4. Initial Gate Assignment"
            )

            initial_solution = greedy_assignment(
                flights,
                gates_df
            )

            initial_result = flights[
                ["flight_number", "airline"]
            ].copy()

            initial_result[
                "assigned_gate"
            ] = initial_result[
                "flight_number"
            ].map(
                initial_solution
            )

            st.dataframe(
                initial_result,
                use_container_width=True
            )

            # ------------------------------------------------
            # QUANTUM-INSPIRED OPTIMIZATION
            # ------------------------------------------------

            st.subheader(
                "5. Quantum-Inspired Optimization"
            )

            optimized_solution, optimized_cost = (
                quantum_inspired_assignment(
                    flights,
                    gates_df
                )
            )

            optimized_result = flights[
                ["flight_number", "airline"]
            ].copy()

            optimized_result[
                "optimized_gate"
            ] = optimized_result[
                "flight_number"
            ].map(
                optimized_solution
            )

            st.write(
                "Optimization Cost:",
                optimized_cost
            )

            st.dataframe(
                optimized_result,
                use_container_width=True
            )

            # ------------------------------------------------
            # DELAY SCENARIO
            # ------------------------------------------------

            st.subheader(
                "6. Dynamic Delay Scenario"
            )

            delayed_flights = create_delay_scenario(
                flights,
                delay_percentage
            )

            st.write(
                f"Delay level: {delay_percentage}%"
            )

            st.dataframe(
                delayed_flights[
                    [
                        "flight_number",
                        "delay_minutes",
                        "delayed_arrival",
                        "delayed_departure"
                    ]
                ],
                use_container_width=True
            )

            # ------------------------------------------------
            # CONFLICT DETECTION
            # ------------------------------------------------

            st.subheader(
                "7. Conflict Detection"
            )

            delay_conflicts = detect_conflicts(
                delayed_flights,
                optimized_solution,
                "delayed_arrival",
                "delayed_gate_release"
            )

            if len(delay_conflicts) == 0:

                st.success(
                    "No gate conflicts detected."
                )

            else:

                st.warning(
                    f"{len(delay_conflicts)} gate conflict(s) detected."
                )

                st.dataframe(
                    delay_conflicts,
                    use_container_width=True
                )

            # ------------------------------------------------
            # ADAPTIVE RE-OPTIMIZATION
            # ------------------------------------------------

            st.subheader(
                "8. Adaptive Re-Optimization"
            )

            adaptive_solution, affected_flights = (
                adaptive_reoptimization(
                    delayed_flights,
                    optimized_solution,
                    gates_df
                )
            )

            st.write(
                "Affected flights:",
                len(affected_flights)
            )

            st.write(
                "Affected flight numbers:",
                list(affected_flights)
            )

            # ------------------------------------------------
            # FINAL VALIDATION
            # ------------------------------------------------

            st.subheader(
                "9. Final Conflict Validation"
            )

            final_conflicts = detect_conflicts(
                delayed_flights,
                adaptive_solution,
                "delayed_arrival",
                "delayed_gate_release"
            )

            if len(final_conflicts) == 0:

                st.success(
                    "✓ Adaptive re-optimization removed all detected gate conflicts."
                )

            else:

                st.warning(
                    f"{len(final_conflicts)} conflict(s) remain."
                )

                st.dataframe(
                    final_conflicts,
                    use_container_width=True
                )

            # ------------------------------------------------
            # FINAL ASSIGNMENT
            # ------------------------------------------------

            st.subheader(
                "10. Final Adaptive Assignment"
            )

            final_result = delayed_flights[
                [
                    "flight_number",
                    "airline",
                    "delay_minutes"
                ]
            ].copy()

            final_result[
                "initial_gate"
            ] = final_result[
                "flight_number"
            ].map(
                optimized_solution
            )

            final_result[
                "final_gate"
            ] = final_result[
                "flight_number"
            ].map(
                adaptive_solution
            )

            final_result[
                "reassigned"
            ] = (
                final_result["initial_gate"]
                != final_result["final_gate"]
            )

            st.dataframe(
                final_result,
                use_container_width=True
            )

            # ------------------------------------------------
            # PERFORMANCE METRICS
            # ------------------------------------------------

            st.subheader(
                "11. Performance Metrics"
            )

            total_flights = len(
                final_result
            )

            reassignments = int(
                final_result["reassigned"].sum()
            )

            unassigned = int(
                final_result["final_gate"].isna().sum()
            )

            metrics = pd.DataFrame({
                "Metric": [
                    "Total Flights",
                    "Affected Flights",
                    "Reassignments",
                    "Remaining Conflicts",
                    "Unassigned Flights"
                ],
                "Value": [
                    total_flights,
                    len(affected_flights),
                    reassignments,
                    len(final_conflicts),
                    unassigned
                ]
            })

            st.dataframe(
                metrics,
                use_container_width=True
            )

            # ------------------------------------------------
            # FINAL STATUS
            # ------------------------------------------------

            if (
                len(final_conflicts) == 0
                and unassigned == 0
            ):

                st.success(
                    "✓ Final assignment is conflict-free and all flights are assigned."
                )

            else:

                st.warning(
                    "Some flights remain unassigned or conflicts remain."
                )

else:

    st.info(
        "Enter your Aviationstack API key in the sidebar "
        "and click 'Fetch Live Flights' to start."
    )
